
function applyTemplate(type) {
    if (type === 'general') { document.getElementById('noteS').value = "general information about ticket rules"; document.getElementById('noteA').value = "advised pax, pax will leave as is"; document.getElementById('noteO').value = "solved"; }
    else if (type === 'change') { document.getElementById('noteS').value = "Guest reached to change ticket"; document.getElementById('noteA').value = "Processed change per fare rules"; document.getElementById('noteO').value = "Solved"; }
    else if (type === 'refund') { document.getElementById('noteS').value = "Guest reached for refund"; document.getElementById('noteA').value = "Processed refund as per airline policy"; document.getElementById('noteO').value = "solved"; }
    else if (type === 'followup') { document.getElementById('noteS').value = "follow up on airline request"; document.getElementById('noteA').value = "request still pending"; document.getElementById('noteO').value = "No further action"; }
}

function generateAndCopyNote() {
    const t = document.getElementById('noteTicket').value.trim();
    const s = document.getElementById('noteS').value.trim();
    const a = document.getElementById('noteA').value.trim();
    const o = document.getElementById('noteO').value.trim();
    copyToClipboard(`**NEW CASE** | ${new Date().toLocaleString()}\nCAC ZD ID: ${t || 'N/A'}\n\n**S:** ${s || 'N/A'}\n\n**A:** ${a || 'N/A'}\n\n**O:** ${o || 'N/A'}`);
}

function initCaseNotes() {
    document.getElementById('btnCopyCaseNote')?.addEventListener('click', generateAndCopyNote);
    document.querySelectorAll('.template-btn').forEach(btn => {
        btn.addEventListener('click', (e) => applyTemplate(e.target.dataset.type));
    });
}