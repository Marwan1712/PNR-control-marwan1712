
function calculateQuick() {
    const input = document.getElementById('quickCalcInput');
    const display = document.getElementById('quickCalcResult');
    const value = input.value.trim();

    if (!value) { 
        display.innerText = "Result: -"; 
        display.classList.add('text-slate-500'); 
        display.removeAttribute('data-res'); 
        return; 
    }
    try {
        const result = Function('"use strict";return (' + value.replace(/[^-+*/(). \d]/g, '') + ')')();
        if (result !== undefined && !isNaN(result)) { 
            display.innerText = `Result: ${result}`; 
            display.classList.add('text-blue-400'); 
            display.setAttribute('data-res', result); 
        } else { 
            display.innerText = "Result: Error"; 
            display.removeAttribute('data-res'); 
        }
    } catch (e) { 
        display.innerText = "Result: ..."; 
        display.removeAttribute('data-res'); 
    }
}

function initCalculator() {
    document.getElementById('quickCalcInput')?.addEventListener('input', calculateQuick);
    document.getElementById('quickCalcInput')?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            const res = document.getElementById('quickCalcResult').getAttribute('data-res');
            if (res) { 
                copyToClipboard(res); 
                showToast(`Result ${res} Copied!`); 
                document.getElementById('quickCalcInput').value = ''; 
                calculateQuick(); 
            }
        }
    });
}